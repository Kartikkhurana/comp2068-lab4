var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/Kartik',function(req,res,next){
  res.render('Kartik',{ title: 'Kartik'});
});
router.get('/Deepika',function(req,res,next){
  res.render('Deepika',{title: 'Deepika'});
});
router.get('/Sannat',function(req,res,next){
  res.render('Sannat',{title:'Sannat'});
});
router.get('/Neeraj',function(req,res,next){
  res.render('Neeraj',{title:'Neeraj'});
});

module.exports = router;
