var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
//  res.send('respond with a resource');
// load a user view instead
var userList = ['kartik','Sannat','Neeraj','Deepika'];
res.render('users',{title:'users list', users: userList});

});

module.exports = router;
